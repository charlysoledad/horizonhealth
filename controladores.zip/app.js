/*:------------------------------------------------------------------------------------------------------
 *:                         HorizonHealth                          
 *:         Archivo de para manipular la base de datos con el CRUD           
 *: Archivo       : app.js
 *: Autor         : Rodrigo Macias Ruiz, Sergio Antonio López Delgado y Manuel Mijares Lara.
 *:                 
 *: Fecha         : 09/10/2024
 *: Herramienta   : JavaScript con Express 
 *: Descripción   : Se realizará un CRUD, para realizar el back-end del SPA
 *: Ult.Modif.    : 09/10/2024
 *: Fecha: 09/10/2024 
 *: Modificó: Rodrigo Macias Ruiz
 *: Modificación: Se realizará un CRUD para manipular el back-end
 *:======================================================================================================
 *: Modificación 1
 *: 09/10/2024: 
 *: Nombre : Rodrigo Macias Ruiz, Sergio Antonio López Delgado y Manuel Mijares Lara.
 *: Se realizó una prueba de conexión de la base de datos
 *: Modificación 2
 *: 15/10/2024: 
 *: Nombre : Rodrigo Macias Ruiz.
 *: Se importo el controlador de usuarios para poder usarlo en la aplicación
 *: Modificación 3
 *: 17/10/2024: 
 *: Nombre : Rodrigo Macias Ruiz.
 *: Se agrego la ruta para el método de inicio de sesión y registro
 *: Modificación 4
 *: 24/10/2024: 
 *: Nombre : Rodrigo Macias Ruiz.
 *: Se agrego la ruta para las diferentes secciones del proyecto (lectura, frases, ejercicio, meditacion y actividad)
 *:------------------------------------------------------------------------------------------------------
 */

const express = require('express');
const app = express();
const db = require('./db');
const usuariosController = require('./controladores/usuariosController');
const frasesController = require('./controladores/frasesController');
const ejerciciosController = require('./controladores/ejerciciosController');
const actividadesController = require('./controladores/actividadesController');
const meditacionController = require('./controladores/meditacionController');
const lecturaController = require('./controladores/lecturaController');

app.use(express.json());

// Ruta para obtener una lectura aleatoria
app.get('/lectura-aleatoria', lecturaController.getRandomLectura);

// Ruta para obtener una frase aleatoria
app.get('/frase-aleatoria', frasesController.getRandomFrase);

// Ruta para obtener un ejercicio aleatorio
app.get('/ejercicio-aleatorio', ejerciciosController.getRandomEjercicio);

// Ruta para obtener una actividad aleatoria
app.get('/actividad-aleatoria', actividadesController.getRandomActividad);

// Ruta para registrar usuario
app.post('/register', usuariosController.registerUser);

// Ruta para iniciar sesión
app.post('/login', usuariosController.loginUser);

// Rutas para la sección de meditación
app.get('/meditaciones', meditacionController.getAllMeditaciones);
app.get('/meditaciones/:id', meditacionController.getMeditacionById);
app.post('/meditaciones', meditacionController.createMeditacion);
app.put('/meditaciones/:id', meditacionController.updateMeditacionById);

app.listen(3100, () => {
    console.log('Servidor escuchando en el puerto 3100');
});
