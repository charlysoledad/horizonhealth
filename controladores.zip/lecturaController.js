/*:------------------------------------------------------------------------------------------------------
 *:                         HorizonHealth                          
 *:         Archivo del controlador de la sección de frases para la sección lectura
 *: Archivo       : lecturaController.js
 *: Autor         : Rodrigo Macias Ruiz, Sergio Antonio López Delgado y Manuel Mijares Lara.
 *:               
 *: Fecha         : 23/10/2024
 *: Herramienta   : JavaScript con Express 
 *: Descripción   : Se realizará el contorlador de la sección sección lectura
 *: Ult.Modif.    : 24/10/2024
 *: Fecha: 24/10/2024 
 *: Modificó: Manuel Mijares Lara
 *: Modificación: Creación de controlador para la sección sección lectura
 *:======================================================================================================
 *: 
 *: 24/10/2024: 
 *: Nombre : Manuel Mijares Lara
 *: Se realizó el controlador para poder gestionar los recursos de la tabla lectura en la base de datos
 *:------------------------------------------------------------------------------------------------------
 */
const db = require('../db'); // Conexión a la base de datos

// Obtener una lectura de manera aleatoria
exports.getRandomLectura = (req, res) => {
    const query = `
    SELECT Lectura.id, Lectura.titulo, Lectura.genero, Lectura.longitud, Actividades.nombre AS actividad_nombre
    FROM Lectura
    JOIN Actividades ON Lectura.actividad_id = Actividades.actividad_id
    ORDER BY RAND() LIMIT 1;
    `;
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error al obtener lectura aleatoria:', err);
            res.status(500).send('Error al obtener lectura');
        } else {
            res.status(200).json(results[0]);
        }
    });
};