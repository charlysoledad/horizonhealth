/*:------------------------------------------------------------------------------------------------------
 *:                         HorizonHealth                          
 *:         Archivo del controlador de la sección de frases para la sección de actividad       
 *: Archivo       : actividadController.js
 *: Autor         : Rodrigo Macias Ruiz, Sergio Antonio López Delgado y Manuel Mijares Lara.
 *:               
 *: Fecha         : 23/10/2024
 *: Herramienta   : JavaScript con Express 
 *: Descripción   : Se realizará el contorlador de la sección de actividad 
 *: Ult.Modif.    : 23/10/2024
 *: Fecha: 24/10/2024 
 *: Modificó: Rodrigo Macias Ruiz
 *: Modificación: Creación de controlador para la sección de actividad
 *:======================================================================================================
 *: 
 *: 23/10/2024: 
 *: Nombre : Rodrigo Macias Ruiz
 *: Se realizó el controlador para poder gestionar los recursos de la tabla actividades en la base de datos
 *:------------------------------------------------------------------------------------------------------
 */

 const db = require('../db');

 // Obtener una actividad de manera aleatoria
 exports.getRandomActividad = (req, res) => {
     const query = 'SELECT * FROM actividades ORDER BY RAND() LIMIT 1';
     db.query(query, (err, results) => {
         if (err) {
             console.error('Error al obtener actividad aleatoria:', err);
             res.status(500).send('Error al obtener actividad');
         } else if (results.length === 0) {
             res.status(404).send('No se encontraron actividades');
         } else {
             res.status(200).json(results[0]);
         }
     });
 };