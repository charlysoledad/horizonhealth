/*:------------------------------------------------------------------------------------------------------
 *:                         HorizonHealth                          
 *:         Archivo de para manipular la base de datos con el CRUD           
 *: Archivo       : app.js
 *: Autor         : Rodrigo Macias Ruiz, Sergio Antonio López Delgado y Manuel Mijares Lara.
 *:                 
 *: Fecha         : 09/10/2024
 *: Herramienta   : JavaScript con Express 
 *: Descripción   : Se realizará un CRUD, para realizar el back-end del SPA
 *: Ult.Modif.    : 09/10/2024
 *: Fecha: 09/10/2024 
 *: Modificó: Rodrigo Macias Ruiz
 *: Modificación: Se realizará un CRUD para manipular el back-end
 *:======================================================================================================
 *: Modificación 1
 *: 09/10/2024: 
 *: Nombre : Rodrigo Macias Ruiz, Sergio Antonio López Delgado y Manuel Mijares Lara.
 *: Se realizó una prueba de conexión de la base de datos
 *: Modificación 2
 *: 15/10/2024: 
 *: Nombre : Rodrigo Macias Ruiz.
 *: Se importo el controlador de usuarios para poder usarlo en la aplicación
 *: 17/10/2024: 
 *: Nombre : Rodrigo Macias Ruiz.
 *: Se agrego la ruta para el método de inicio de sesión
 *:------------------------------------------------------------------------------------------------------
 */

 const db = require('../db');

// Obtener un ejercicio de manera aleatoria
exports.getRandomEjercicio = (req, res) => {
    const query = 'SELECT * FROM ejercicios ORDER BY RAND() LIMIT 1';
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error al obtener ejercicio aleatorio:', err);
            res.status(500).send('Error al obtener ejercicio');
        } else if (results.length === 0) {
            res.status(404).send('No se encontraron ejercicios');
        } else {
            res.status(200).json(results[0]);
        }
    });
};