/*:------------------------------------------------------------------------------------------------------
 *:                         HorizonHealth                          
 *:         Archivo del controlador de la sección de frases para la sección enseñanza del dia        
 *: Archivo       : frasesController.js
 *: Autor         : Rodrigo Macias Ruiz, Sergio Antonio López Delgado y Manuel Mijares Lara.
 *:               
 *: Fecha         : 23/10/2024
 *: Herramienta   : JavaScript con Express 
 *: Descripción   : Se realizará el contorlador de la sección enseñanza del dia
 *: Ult.Modif.    : 24/10/2024
 *: Fecha: 24/10/2024 
 *: Modificó: Sergio Antonio Lopez Delgado
 *: Modificación: Creación de controlador para la sección enseñanza del dia
 *:======================================================================================================
 *: 
 *: 23/10/2024: 
 *: Nombre : Sergio Antonio Lopez Delgado
 *: Se realizó el controlador para poder gestionar los recursos de la tabla frases en la base de datos
 *:------------------------------------------------------------------------------------------------------
 */

const db = require('../db');

// Obtener una frase de manera aleatoria
exports.getRandomFrase = (req, res) => {
    const query = 'SELECT * FROM frases ORDER BY RAND() LIMIT 1';
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error al obtener frase aleatoria:', err);
            res.status(500).send('Error al obtener frase');
        } else if (results.length === 0) {
            res.status(404).send('No se encontraron frases');
        } else {
            res.status(200).json(results[0]);
        }
    });
};