/*:------------------------------------------------------------------------------------------------------
 *:                         HorizonHealth                          
 *:         Archivo del controlador de la sección de meditación          
 *: Archivo       : meditacionController.js
 *: Autor         : Rodrigo Macias Ruiz, Sergio Antonio López Delgado y Manuel Mijares Lara.
 *:               
 *: Fecha         : 24/10/2024
 *: Herramienta   : JavaScript con Express 
 *: Descripción   : Se realizará el contorlador de la sección de meditación
 *: Ult.Modif.    : 24/10/2024
 *: Fecha: 24/10/2024 
 *: Modificó: Manuel Mijares Lara 
 *: Modificación: Creación de controlador para la sección de meditación
 *:======================================================================================================
 *: 
 *: 24/10/2024: 
 *: Nombre : Manuel Mijares Lara
 *: Se realizó el controlador para poder gestionar los recursos de la tabla Meditacion en la base de datos
 *:------------------------------------------------------------------------------------------------------
 */
const db = require('../db');

// Obtener todas las meditaciones
exports.getAllMeditaciones = (req, res) => {
    const query = 'SELECT * FROM Meditacion';
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error al obtener meditaciones:', err);
            res.status(500).send('Error al obtener meditaciones');
        } else {
            res.status(200).json(results);
        }
    });
};

// Obtener una meditación por su ID
exports.getMeditacionById = (req, res) => {
    const id = req.params.id;
    const query = 'SELECT * FROM Meditacion WHERE id = ?';
    db.query(query, [id], (err, results) => {
        if (err) {
            console.error('Error al obtener la meditación:', err);
            res.status(500).send('Error al obtener la meditación');
        } else if (results.length === 0) {
            res.status(404).send('Meditación no encontrada');
        } else {
            res.status(200).json(results[0]);
        }
    });
};
// Crear una nueva meditación
exports.createMeditacion = (req, res) => {
    const { duracion, completado } = req.body;
    const query = 'INSERT INTO Meditacion (duracion, completado) VALUES (?, ?)';
    db.query(query, [duracion, completado], (err, results) => {
        if (err) {
            console.error('Error al crear la meditación:', err);
            res.status(500).send('Error al crear la meditación');
        } else {
            res.status(201).send('Meditación creada exitosamente');
        }
    });
};

// Actualizar la duración y el estado de completado de una meditación
exports.updateMeditacionById = (req, res) => {
    const id = req.params.id;
    const { duracion, completado } = req.body;
    const query = 'UPDATE Meditacion SET duracion = ?, completado = ? WHERE id = ?';
    db.query(query, [duracion, completado, id], (err, results) => {
        if (err) {
            console.error('Error al actualizar la meditación:', err);
            res.status(500).send('Error al actualizar la meditación');
        } else if (results.affectedRows === 0) {
            res.status(404).send('Meditación no encontrada');
        } else {
            res.status(200).send('Meditación actualizada exitosamente');
        }
    });
};